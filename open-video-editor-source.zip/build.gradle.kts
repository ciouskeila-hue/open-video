// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    id("com.android.application") version "8.6.0" apply false
    id("org.jetbrains.kotlin.android") version "1.8.10" apply false
}

allprojects {
    layout.buildDirectory.set(layout.projectDirectory.dir("build_v18"))
}